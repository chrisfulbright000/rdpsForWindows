# myfreerdp
FREE RDP WINDOWS SERVER

Create Free RDP 7GB RAM 

..................................................................................................................................................

Follow these instructions 

1) Click Fork to get started. 

2) Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
 
3) In this repository go to Settings> Secrets> New repository secret Name: NGROK_AUTH_TOKEN Value: https://dashboard.ngrok.com/auth/your-authtoken copy and paste authtoken in the value Click add secret.

4) Go to Action (if you see any watning click "I understand") > FreeRDP > run workflow Refresh website - go to FreeRDP > build Click the down arrow "RDP INFO LOGIN" To get IP, User, Password.

5) ENJOY

<img src="https://media.giphy.com/media/diUKszNTUghVe/giphy.gif" width="500" height="500" />


.........................................................................................................................................................
